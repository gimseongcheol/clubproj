class Event {
  String name;

  Event(this.name);

  @override
  String toString() {
    return name;
  }
}
