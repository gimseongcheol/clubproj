package com.example.team_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
